#' measure the distance with mathod Eu
#' 
#' @param array1 array1 one array with the class numeric just like c(1,2,4,5)
#' @param array2 another array with the class numeric
#' @return the distance between two arrays
Eu <- function(array1, array2){
  s=0
  array1 = (array1-mean(array1))/sd(array1)
  array2 = (array2-mean(array2))/sd(array2)
  for (i in 1:length(array1)){
    s=s+(array1[i]-array2[i])^2
  }
  out = sqrt(s)
  return (out)
}
#' choose the method to measure the distance
#' 
#' @param method the method used to meansure the distance
#' @param array1 one array with the class numeric
#' @param array2 another array with the class numeric
#' @return the distance between two arrays
Rcpp::sourceCpp('src/dtw_distance.cpp')
Rcpp::sourceCpp('src/distance.cpp')
source('R/twed.R')
T <- function(method, array1, array2){
  if (method=='Eu'){
    return (Eu(array1,array2))
  }else if(method=='Dwt'){
    return (dwt(array1, array2,length(array1)-length(array2)))
  }else if(method=='Canberra'){
    return (Canberra(array1, array2))
  }else if(method=='Chi'){
    return (Chi_square(array1, array2))
  }else if(method=='twed'){
    tA=c(1:length(array1))
    tB=c(1:length(array2))
    return (twed(array1,tA,array2,tB))
  }else {return (Euclidean_Distance(array1,array2))}
}

#' classify the new series
#' 
#' @param method the method used to meansure the distance
#' @param array1 one array with the class numeric
#' @param listclass the list containing the several class with each class is also a list of some arrays
#' @param k the nearnst points it needs
#' @return the most probable class the new series belongs to
Knn_dis <- function(array1, listclass, k, method){
  df = data.frame()
  l=length(listclass)
  j=0
  past=0
  while(j<l){
    classnew = listclass[[j+1]]
    for (i in 1:length(classnew)){
      dist = T(method, array1, classnew[[i]])
      label = j+1
      df[i+past,1] = dist
      df[i+past,2] = label
    }
    j=j+1
    past=past+length(classnew)
  }
  temp = df[order(df[1]),]
  temp = temp[1:k,]
  temp = as.data.frame(table(temp[2]))
  if (length(temp[,1])>1 & temp[1,2]==temp[2,2]){
    a=sample(2,1)
    return (temp[a,1])
  }
  return (temp[1,1])
}
