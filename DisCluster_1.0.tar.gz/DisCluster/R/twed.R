Dlp <- function(A, B, p=2){
  ## Calculate the fundamental distance
  cost = sum(abs(A-B)^p)
  return(cost^(1/p))
}


#' Main Function
#' Calculate the Time Wrap Edit Distance
#' @param A  Time series A
#' @param timeA  the timestamp of A
#' @param B  Time series B
#' @param timeB: the timestamp of B
#' @param nu  Elasticity parameter
#' @param lambda Penalty for deletion
#' @param standardize  Whether standardize the data or not


twed <- function(A, timeA, B, timeB, nu=0.1, lambda=0.2, standardize=TRUE){

  if(standardize==TRUE){
    A = A / mean(A)
    B = B / mean(B)
  }

  A = c(0, A)
  B = c(0, B)
  timeA = c(0, timeA)
  timeB = c(0, timeB)
  
  n = length(A)
  m = length(B)

  d = rep(1, m) * Inf
  d[1] = 0

  
  for(i in 2:n){
    old = d[1]
    for(j in 2:m){
      C = rep(1, 3) * Inf
      
      d[1] = Inf
      temp = d[j]
      
      C[1] = (
        d[j]
        + Dlp(A[i-1], A[i])
        + nu * (timeA[i] - timeA[i-1])
        + lambda
      )
      
      C[2] = (
        d[j-1]
        + Dlp(B[j-1], B[j])
        + nu * (timeB[j] - timeB[j-1])
        + lambda
      )
      
      C[3] = (
        old
        + Dlp(A[i], B[j])
        + Dlp(A[i-1], B[j-1])
        + nu * (abs(timeA[i] - timeB[j]) + 
                  abs(timeA[i-1] - timeB[j-1]))
      )
      
      d[j] = min(C)
      old = temp
    }
  }
  distance = d[m]
  return(distance)
}