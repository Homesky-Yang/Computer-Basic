#' plot the series
#' 
#' @param listclass the list containing the several class with each class is also a list of some arrays
#' @return a plot
library(ggplot2)
library(reshape2)
plot_class <- function(listclass){
  plotlist=list()
  l = length(listclass)
  j=0
  df=data.frame(index=c(1:100))
  while(j<l){
    classnew = listclass[[j+1]]
    for (i in 1:length(classnew)){
      array = (classnew[[i]]-mean(classnew[[i]]))/sd(classnew[[i]])
      temp=data.frame(label1=array)
      df = cbind(df, temp)
      df[paste('label',(j+1),i,sep='-')]=df[length(df)]
      df=df[-(length(df)-1)]
    }
    j=j+1
  }
  mydata <- melt(df,id="index")
  p=ggplot(data = mydata,aes(x=index,y=value,group = variable,color=variable,shape=variable))+
    geom_point()+
    geom_line()+
    xlab("index")+
    ylab("value")+
    theme_bw() +
    theme(panel.grid.major=element_line(colour=NA),
          panel.background = element_rect(fill = "transparent",colour = NA),
          plot.background = element_rect(fill = "transparent",colour = NA),
          panel.grid.minor = element_blank(),
          text = element_text(family = "STXihei"),
          legend.position = c(.075,.715),
          legend.box.background = element_rect(color="black"))
  
  return(p)
}

