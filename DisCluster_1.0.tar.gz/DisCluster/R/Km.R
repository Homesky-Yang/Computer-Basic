#' measure the distance with mathod Eu
#' 
#' @param array1 array1 one array with the class numeric just like c(1,2,4,5)
#' @param array2 another array with the class numeric
#' @return the distance between two arrays
Eu <- function(array1, array2){
  s=0
  array1 = (array1-mean(array1))/sd(array1)
  array2 = (array2-mean(array2))/sd(array2)
  for (i in 1:length(array1)){
    s=s+(array1[i]-array2[i])^2
  }
  out = sqrt(s)
  return (out)
}

#' choose the method to measure the distance
#' 
#' @param method the method used to meansure the distance
#' @param array1 one array with the class numeric
#' @param array2 another array with the class numeric
#' @return the distance between two arrays
Rcpp::sourceCpp('src/dtw_distance.cpp')
Rcpp::sourceCpp('src/distance.cpp')
source('R/twed.R')
T <- function(method, array1, array2){
  if (method=='Eu'){
    return (Eu(array1,array2))
  }else if(method=='Dwt'){
    return (dwt(array1, array2,length(array1)-length(array2)))
  }else if(method=='Canberra'){
    return (Canberra(array1, array2))
  }else if(method=='Chi'){
    return (Chi_square(array1, array2))
  }else if(method=='twed'){
    tA=c(1:length(array1))
    tB=c(1:length(array2))
    return (twed(array1,tA,array2,tB))
  }else {return (Euclidean_Distance(array1,array2))}
}

#' find out the center array of the cluster
#' 
#' @param method the method used to meansure the distance
#' @param class1 the cluster with the structure of the list
#' @return the center array with the structure of the array
Center <- function(class1,method){
  len = length(class1)
  dis=10000000
  for (i in 1:len){
    dist=0
    for (j in 1:len){
      dist = dist+T(method,(class1[[i]]),(class1[[j]]) )
    }
    if (dist<dis){
      dis=dist
      center = class1[[i]]
      }
  }
  return (center)
}

#' cluster
#' 
#' @param method the method used to meansure the distance
#' @param df the dataframe that each column is a array
#' @param k the original centers given
#' @param Initial whether to use KMeans++ or not
#' @return a list of two classes
Km <- function(df,method,k=2,Initial=FALSE){
  len = length(df)
  if (Initial==TRUE){
    s = Initial_center(df, method, k)
    center1 = s[[1]]
    center2 = s[[2]]
    class1 = as.data.frame(s[[1]])
    class2 = as.data.frame(s[[2]])
  }else{
    set.seed(2021)
    a = sample(len, k)
    center1 = df[[a[1]]]
    center2 = df[[a[2]]]
    class1 = df[a[1]]
    class2 = df[a[2]]
  }
  for (i in 3:len){
    dist1 = T(method,df[[1]], center1)
    dist2 = T(method,df[[1]], center2)
    if (dist1 <= dist2){
      class1 = c(class1, df[i])
    }else{class2 = c(class2, df[i])}
  }
  epoch=0
  while (epoch<10){
    #cat(length(class1),length(class2),'....')
    center1=(Center(class1,method))
    center2=(Center(class2,method))
    class1 = as.data.frame(center1)
    class2 = as.data.frame(center2)
    for (i in 1:len){
      if (df[i][1,]!=center1[1] & df[i][1,]!=center2[1]){
        dist1 = T(method,df[[i]], center1)
        dist2 = T(method,df[[i]], center2)
        if (dist1<dist2){
          class1 = c(class1, df[i])
        }else(class2 = c(class2, df[i]))
      }
    }
    epoch = epoch+1
  }
  return (list(class1,class2))
}

#' KMeans++ initial the first k centers
#' 
#' @param method the method used to meansure the distance
#' @param df the dataframe that each column is a array
#' @param k the original centers given
#' @return a list of k centers
Initial_center <- function(df, method, k){
  len = length(df)
  set.seed(2021)
  a = sample(len,1)
  center1 = df[[a]]
  listcenter =list(center1)
  count = 1
  while (count<k){
    dist=-1
    for(i in 1:len){
      j=0
      dc = 1000000
      while (j<count){
        dis = T(method, df[[i]], listcenter[[j+1]])
        if(dis<dc){
          dc = dis
          precenter = df[[i]]
        }
        j=j+1
      }
      if (dc!=0 & dc>dist){
        dist=dc
        precenters = precenter
      }
    }
    count =count +1
    listcenter[[count]]=precenters
  }
  return (listcenter)
}
