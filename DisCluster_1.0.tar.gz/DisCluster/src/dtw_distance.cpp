#include <RcppArmadillo.h>
#include <cmath> 
// [[Rcpp::depends(RcppArmadillo)]] 
// [[Rcpp::export]]
float compare_min3(float x,float y, float z){
  if(x<=y&&x<=z){
    return x;
  }
  else if(y<=x&&y<=z){
    return y;
  }
  else{
    return z;
  }
}  

// [[Rcpp::export]]
float compare_max(float x,float y){
  if(x>=y){
    return x;
  }
  else{
    return y;
  }
}  
// [[Rcpp::export]]
float compare_min(float x,float y){
  if(x<=y){
    return x;
  }
  else{
    return y;
  }
}  
// [[Rcpp::export]]
float dwt(arma::vec a, arma::vec b, int window){
  arma::vec a_norm = normalise(a);
  arma::vec b_norm = normalise(b);
  const float inf = arma::datum::inf;
  int n = a.n_elem;
  int m = b.n_elem;
  int d = abs(m-n);
  int w = compare_min(d,window);
  arma::Mat<float> M(n+1, m+1, arma::fill::ones);
  M = M*inf;
  M(0,0) = 0;
  for(int i = 1;i <= n;i++){
    for(int j = compare_max(1,i-w);j<=compare_min(i+w,m);j++){
      float cost = abs(a_norm(i-1) - b_norm(j-1)); 
      float last_min = compare_min3(M(i,j-1),M(i-1,j),M(i-1,j-1));
      M(i,j) = last_min + cost;
    }
  }
  int col = n;
  int row = m;
  while(M(col,row) == inf){
    if(col>row){
      col = col - 1;
    }
    else if(row>col){
      row = row - 1;
    }
  }
  return M(col,row);
}
