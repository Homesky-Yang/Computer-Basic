#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
#include <cmath>
#define _USE_MATH_DEFINES
#include <math.h>

//' The function of standardize is to achieve standardization
//' 
//' @param x is a vector
//' @return a vector that have been standardized
arma::vec standardize(arma::vec x){
  int n = x.n_elem;
  arma::vec d(n);
  double a = mean(x);
  double s = 0;
  for(int i = 0;i < n;i++){
    s += (x[i]-a)*(x[i]-a)/(n-1);
  }
  for(int j = 0;j < n;j++){
    d[j] = (x[j]-a)/sqrt(s);
  }
  return d;
}

//' The function of Euclidean_Distance is to calculate Euclidean distance
//' 
//' @param x is a vector
//' @param y is a vector
//' @return return the euclidean distance of x and y
// [[Rcpp::export]]
double Euclidean_Distance(arma::vec x,arma::vec y){
  x = standardize(x);
  y = standardize(x);
  double square = 0;
  int n = x.n_elem;
  for(int i=0;i<n;i++){
    square += (x[i]-y[i])*(x[i]-y[i]);
    }
  return sqrt(square);
}

//' The function of Mahalanobis_Distance is to calculate Mahalanobis distance
//' 
//' @param x is a vector
//' @param y is a vector
//' @return return the Mahalanobis distance of x and y
//' Obtain the covariance matrix of two samples S
//' Using Cholesky decomposition L
// [[Rcpp::export]]
double Mahalanobis_Distance(arma::vec x,arma::vec y){
  x = standardize(x);
  y = standardize(x);
  int n = x.n_elem;
  arma::vec mean = (x+y)/2;
  arma::mat S1(2,n);
  S1.row(0) = x.t();
  S1.row(1) = y.t();
  arma::mat S = cov(S1);
  arma::mat L= chol(S, "lower");
  arma::vec g = solve(L,x-y);
  double square = sum(g % g);
  return sqrt(square);
}

//' The function of Minkowski_Distance is to calculate Minkowski distance
//' 
//' @param x is a vector
//' @param y is a vector
//' @param p is a constant
//' @return return the Minkowski distance of x and y
//' When p = 1��Get the absolute distance, also known as Manhattan distance
//' When p = 2, the Euclidean distance is obtained
//' When P tends to infinity,get the Chebyshev distance
// [[Rcpp::export]]
double Minkowski_Distance(arma::vec x,arma::vec y,double p){
  x = standardize(x);
  y = standardize(x);
  double sum = 0;
  int n = x.n_elem;
  for(int i=0;i<n;i++){
    sum += pow(x[i]-y[i],p);
  }
  return pow(abs(sum),1/p);
}

//' The function of Cosine_Similarity is to calculate cosine similarity of x and y
//' 
//' @param x is a vector
//' @param y is a vector
//' @return return the cosine similarity of x and y
// [[Rcpp::export]]
double Cosine_Similarity(arma::vec x,arma::vec y){
  x = standardize(x);
  y = standardize(x);
  double dotsum = dot(x, y);
  double normx = norm(x);
  double normy = norm(y);
  return dotsum/(normx*normy);
}

//' The function of Canberra is to calculate Canberra distance of x and y
//' 
//' @param x is a vector
//' @param y is a vector
//' @return return the Canberra distance of x and y
// [[Rcpp::export]]
double Canberra(arma::vec x,arma::vec y){
  x = standardize(x);
  y = standardize(x);
  int n = x.n_elem;
  arma::vec t(n, arma::fill::zeros);
  for(int i=0;i<n;i++){
    t[i] = abs(x[i]-y[i])/(abs(x[i])+abs(y[i]));
  }
  return sum(t);
}

//' The function of Chi_square is to calculate Chi_square distance of x and y
//' 
//' @param x is a vector
//' @param y is a vector
//' @return return the Chi_square distance of x and y
// [[Rcpp::export]]
double Chi_square (arma::vec x,arma::vec y){
  x = standardize(x);
  y = standardize(x);
  int n = x.n_elem;
  arma::vec mean = (x+y)/2;
  double s1 = 0;
  double s2 = 0;
  for(int i=0;i<n;i++){
    s1 += pow((x[i]-mean[i])/mean[i],2);
  }
  for(int j=0;j<n;j++){
    s2 += pow((y[j]-mean[j])/mean[j],2);
  }
  return sqrt(s1+s2);
}
